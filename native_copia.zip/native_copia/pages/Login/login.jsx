import React, { useState } from "react";
import axios from "axios";
import { StyleSheet, Text, View, TextInput, Button, Alert } from "react-native";

export default function App() {
    const [userId, setUserId] = useState(0)
    const [usuario, setUsuario] = useState('')
    const [cpf, setcpf] = useState('')
    const [email, setEmail] = useState('')
    const [senha, setSenha] = useState('')

    const [userAdd, setUseradd] = useState('')

    /*const buscar = ()=>{
        axios.get('http://127.0.0.1:8000/api/usuario/' + userId)
        .then((res)=>{
            setUsuario(res.data.nome)
            setcpf(res.data.cpf)
            setEmail(res.data.email)
            setSenha(res.data.senha)

            
        })
    }

    const adicionar = ()=>{
        axios.post('http://127.0.0.1:8000/api/usuarios',
        {
            nome: userAdd,
            cidade: cityAdd
        },
        {}
        )
    }
*/
   
}