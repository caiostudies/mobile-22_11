import { Text, View, TouchableOpacity } from 'react-native';
import { AntDesign } from "@expo/vector-icons";
import { Ionicons } from '@expo/vector-icons';
import {Entypo} from '@expo/vector-icons';
import style from './1.module.css';

export default function index({navigation}) {

    function Cartoes(){
        navigation.navigate('Cartoes')
      }

    return (
        <View style={style.container}>
            <View style={style.bg}>

            <TouchableOpacity style={style.sair}>
                <AntDesign
                    name="export"
                    size={30}
                    color={'#fff'}
                    onPress={Cartoes}
                />
             </TouchableOpacity>



                <TouchableOpacity style={style.elipse}>
                    <AntDesign
                    name='creditcard'
                    size={30}
                    color={'#fff'}
          
                    />
                </TouchableOpacity>

                <Text style={style.titulo}>Cartões</Text>

                <Text style={style.sub}>Cartões de Débito</Text>


                <TouchableOpacity style={style.card}>
                    <Text style={style.visa}>VISA GOLD</Text>
                    <Text style={style.visa2}>VISA</Text>
                    <Text style={style.numeros}>1234 5678 9000 1234</Text>
                    <Text style={style.validade}>Validade</Text>
                    <Text style={style.van}>12/34</Text>
                    <Text style={style.seguranca}>Código de segurança(CVV)</Text>
                    <Text style={style.ns}>123</Text>
                    <Text style={style.nome}>CAIO TAWFIQ</Text>
                </TouchableOpacity>

                <TouchableOpacity style={style.menu}>
                    <Ionicons 
                    name='home'
                    size={30}
                    color={'#fff'}
                    />

                    <AntDesign style={style.code}
                    name='qrcode'
                    size={30}
                    color={'#fff'}
                    />

                    <Entypo style={style.buy}
                    name='shopping-bag'
                    size={30}
                    color={'#fff'}
                    />

                </TouchableOpacity>



            </View>
   

        </View>
    
      
    )
}