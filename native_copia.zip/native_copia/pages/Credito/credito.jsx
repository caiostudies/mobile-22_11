import { useNavigation } from "@react-navigation/native";

import { Text, View, TouchableOpacity } from 'react-native';
import { AntDesign } from "@expo/vector-icons";
import { Ionicons } from '@expo/vector-icons';
import {Entypo} from '@expo/vector-icons';
import { FontAwesome } from '@expo/vector-icons'; 
import style from './credito.css';


export default function index({navigation}){
    const{navigate}=useNavigation()
    return(
        <View style={style.container}>
        <View style={style.bg}>

        <TouchableOpacity style={style.sair}  onPress={()=>navigate("Cartoes")}>
            <AntDesign
                name="export"
                size={30}
                color={'#fff'}
                
            />
         </TouchableOpacity>



            <TouchableOpacity style={style.elipse}>
                <FontAwesome name="cc-mastercard" size={30} color="white" />
            </TouchableOpacity>

            <Text style={style.titulo}>Cartões</Text>

            <Text style={style.sub}>Cartões de Crédito</Text>


            <TouchableOpacity style={style.card}>
                <Text style={style.visa}>VISA GOLD</Text>
                <Text style={style.visa2}>VISA</Text>
                <Text style={style.numeros}>1234 5678 9000 1234</Text>
                <Text style={style.validade}>Validade</Text>
                <Text style={style.van}>43/21</Text>
                <Text style={style.seguranca}>Código de segurança(CVV)</Text>
                <Text style={style.ns}>123</Text>
                <Text style={style.nome}>CAIO TAWFIQ</Text>
            </TouchableOpacity>

            <TouchableOpacity style={style.menu}>
                <Ionicons 
                name='home'
                size={30}
                color={'#fff'}
                />

                <AntDesign style={style.code}
                name='qrcode'
                size={30}
                color={'#fff'}
                />

                <Entypo style={style.buy}
                name='shopping-bag'
                size={30}
                color={'#fff'}
                />

            </TouchableOpacity>



        </View>


    </View>
      
       


        
    )
}