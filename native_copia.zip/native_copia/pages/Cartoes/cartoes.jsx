import { Text, View, TouchableOpacity } from 'react-native';
import { AntDesign } from "@expo/vector-icons";
import { Ionicons } from '@expo/vector-icons'; 
import { FontAwesome } from '@expo/vector-icons'; 
import { MaterialCommunityIcons } from '@expo/vector-icons';
import {Entypo} from '@expo/vector-icons'; 
import style from './cartoes.module.css';
import { useNavigation } from '@react-navigation/native';

export default function index({navigation}) {
    const{navigate}=useNavigation()
    function Home(){
        navigation.navigate('Home')
      }

    function debito(){
        navigation.navigate('Cartao1')
    }

    return (
        <View style={style.container}>
            <View style={style.bg}>

                <TouchableOpacity style={style.sair} onPress={()=>navigate("Home")}>
                <AntDesign name="close" size={24} color="black" />
                </TouchableOpacity>

                <TouchableOpacity style={style.elipse}>
                    <Ionicons
                        name="card"
                        size={30}
                        color={'#fff'}
                    />
                </TouchableOpacity>

                <Text style={style.titulo}>Cartões</Text>

                <Text style={style.sub}>Cartões físicos</Text>

                <TouchableOpacity style={style.debito} onPress={()=>navigate("Cartao1")}>
                    <AntDesign 
                        name='creditcard'
                        size={30}
                        color={'#fff'}
                    />
                    <Text style={style.text_deb}>Cartão de Débito</Text>
                </TouchableOpacity>
                <TouchableOpacity style={style.credito} onPress={()=>navigate("Credito")}>
                    <FontAwesome name="cc-mastercard" size={30} color="white" />
                    <Text style={style.text_cred}>Cartão de Crédito</Text>
                </TouchableOpacity>
                
                <TouchableOpacity style={style.plus}>
                    <AntDesign  name="plus" size={20} color="black"/>
                    <Text style={style.text_plus}>Pedir novo cartão</Text>
                </TouchableOpacity>

             
                <Text style={style.linha}></Text>

                <Text style={style.digital}>Cartões digitais</Text>
                <TouchableOpacity style={style.deb_cred}>
                    <MaterialCommunityIcons name="credit-card-multiple" size={30} color="white" />
                    <Text style={style.text_digi}>Cartão de débito/Crédito</Text>
                </TouchableOpacity>

                <TouchableOpacity style={style.create}>
                    <AntDesign  name="plus" size={20} color="black"/>
                    <Text style={style.digi_plus}>Criar novo cartão</Text>

                </TouchableOpacity>

                <TouchableOpacity style={style.menu}>
                    <Ionicons 
                    name='home'
                    size={30}
                    color={'#fff'}
                    />

                    <AntDesign style={style.code}
                    name='qrcode'
                    size={30}
                    color={'#fff'}
                    />

                    <Entypo style={style.buy}
                    name='shopping-bag'
                    size={30}
                    color={'#fff'}
                    />

                </TouchableOpacity>



                



            </View>
       

        </View>
      
    )
}